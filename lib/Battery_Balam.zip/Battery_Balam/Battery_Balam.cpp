#include "Battery_Balam.h"

//This function returns the color in RGB of the Motors battery level.
Colors_Motor GET_COLOR_MOTORS_BATTERY(int PIN_ADC_BAT_MOT){
  int MOT_BAT_RAW = analogRead(PIN_ADC_BAT_MOT);
  //Serial.println(MOT_BAT_RAW);
  
  Colors_Motor color;
  if (MOT_BAT_RAW >= 129 && MOT_BAT_RAW <= 172){
    color.red_mot = 255;
    color.blue_mot = 0;
    color.green_mot = 5.9302*MOT_BAT_RAW-765;
  } 
  else if(MOT_BAT_RAW >= 173){
    color.red_mot = -5.9302*MOT_BAT_RAW+1280.9;
    color.blue_mot = 0;
    color.green_mot = 255;
  }
  return color;
}

//This function returns the color in RGB of the ESP battery level.
Colors_ESP GET_COLOR_ESP_BATTERY(int PIN_ADC_BAT_ESP){
  int ESP_BAT_RAW = analogRead(PIN_ADC_BAT_ESP);
  //Serial.println(ESP_BAT_RAW);

  Colors_ESP color;

  if (ESP_BAT_RAW >= 128 && ESP_BAT_RAW <= 172){
    color.red_esp = 255;
    color.blue_esp = 0;
    color.green_esp = 15.938*ESP_BAT_RAW-1673.4;
  } 
  else if(ESP_BAT_RAW >= 122){
    color.red_esp = -17*ESP_BAT_RAW+2329;
    color.blue_esp = 0;
    color.green_esp = 255;
  }

  return color;
}

//This function sets the color to the MOTOR battery level NeoPixel.
void MOTORS_BATTERY_ADC(Adafruit_NeoPixel& NEO_BAT, int PIN_ADC_BAT_MOT){
  int MOT_BAT_RAW = analogRead(PIN_ADC_BAT_MOT);
  //Serial.println(MOT_BAT_RAW);
  int red_mot = 0;
  int green_mot = 0;
  int blue_mot = 0;

  if (MOT_BAT_RAW >= 129 && MOT_BAT_RAW <= 172){
    red_mot = 255;
    blue_mot = 0;
    green_mot = 5.9302*MOT_BAT_RAW-765;
  } 
  else if(MOT_BAT_RAW >= 173){
    red_mot = -5.9302*MOT_BAT_RAW+1280.9;
    blue_mot = 0;
    green_mot = 255;
  }
  else if(MOT_BAT_RAW > 0 && MOT_BAT_RAW <129){
    red_mot = 255;
    blue_mot = 0;
    green_mot = 0;    
  }
  NEO_BAT.setPixelColor(0, NEO_BAT.Color(red_mot, green_mot, blue_mot));
  NEO_BAT.show();
}

//This function returns the Motor battery level (0-100).
int MOTORS_BATTERY_value(int PIN_ADC_BAT_MOT){
  int MOT_BAT_RAW = analogRead(PIN_ADC_BAT_MOT);
  //Serial.println(MOT_BAT_RAW);
  int value = ((MOT_BAT_RAW-129)*100)/(216-129);
  if (value < 0) return 0;   
  if (value > 100) return 100; 

  return value;
}

//This function sets the color to the ESP battery level NeoPixel.
void ESP_BATTERY(Adafruit_NeoPixel& NEO_BAT, int PIN_ADC_BAT_ESP){
  int ESP_BAT_RAW = analogRead(PIN_ADC_BAT_ESP);
  //Serial.println(ESP_BAT_RAW);
  int red_esp = 0;
  int green_esp = 0;
  int blue_esp = 0; 

  if (ESP_BAT_RAW >= 105 && ESP_BAT_RAW <= 121){
    red_esp = 255;
    blue_esp = 0;
    green_esp = 15.938*ESP_BAT_RAW-1673.4;
  } 
  else if(ESP_BAT_RAW >= 122){
    red_esp = -17*ESP_BAT_RAW+2329;
    blue_esp = 0;
    green_esp = 255;
  }
 else if(ESP_BAT_RAW > 0 && ESP_BAT_RAW <105){
    red_esp = 255;
    blue_esp = 0;
    green_esp = 0;    
  }
  NEO_BAT.setPixelColor(1, NEO_BAT.Color(red_esp, green_esp, blue_esp));
  NEO_BAT.show();  
}


//This function returns the ESP battery level (0-100).
int ESP_BATTERY_value(int PIN_ADC_BAT_ESP){
  int ESP_BAT_RAW = analogRead(PIN_ADC_BAT_ESP);
  //Serial.println(ESP_BAT_RAW);
  int value = ((ESP_BAT_RAW-105)*100)/(122-105);
  if (value < 0) return 0;   
  if (value > 100) return 100; 

  return value;
}


bool Working(Adafruit_NeoPixel& NEO_BAT){
  //Serial.println(F("BQ25887 is working..."));
  NEO_BAT.setPixelColor(0, NEO_BAT.Color(0,0, 255));
  NEO_BAT.show();
  delay(500);
  
  NEO_BAT.setPixelColor(0, NEO_BAT.Color(0,0, 0));
  NEO_BAT.show();
  delay(500);

  NEO_BAT.setPixelColor(0, NEO_BAT.Color(0,0, 255));
  NEO_BAT.show();
  delay(500);
  
  NEO_BAT.setPixelColor(0, NEO_BAT.Color(0,0, 0));
  NEO_BAT.show();
  return true;
}

bool NOT_Working(Adafruit_NeoPixel& NEO_BAT){
  //Serial.println(F("BQ25887 is NOT working..."));
  NEO_BAT.setPixelColor(0, NEO_BAT.Color(128, 0, 128));
  NEO_BAT.show();
  delay(500);

  NEO_BAT.setPixelColor(0, NEO_BAT.Color(0, 0, 0));
  NEO_BAT.show();
  delay(500);

  NEO_BAT.setPixelColor(0, NEO_BAT.Color(128, 0, 128));
  NEO_BAT.show();
  delay(500);

  NEO_BAT.setPixelColor(0, NEO_BAT.Color(0, 0, 0));
  NEO_BAT.show();
  return false;
}


//This function sets the color to the MOTOR battery level NeoPixel.
void MOTORS_BATTERY_I2C(Adafruit_NeoPixel& NEO_BAT, BQ25887& charger, bool status){
  if(!status){
    return;
  }


  charger.setADC_EN(true);
  charger.setEN_CHG(true);
  charger.pollAllRegs();

  float ESP_MOT_RAW = charger.getADC_VBAT();
  charger.wdReset();
  //Serial.print("MOT RAW: ");
  //Serial.println(ESP_MOT_RAW);
  int red_mot = 0;
  int green_mot = 0;
  int blue_mot = 0;

  if (ESP_MOT_RAW >= 5 && ESP_MOT_RAW <= 6.67){
    red_mot = 255;
    blue_mot = 0;
    green_mot = 152.69*ESP_MOT_RAW-763.47;
  }
  else if(ESP_MOT_RAW >= 6.7){
    red_mot = -150.89*ESP_MOT_RAW+1267.5;
    blue_mot = 0;
    green_mot = 255;
  }

  NEO_BAT.setPixelColor(0, NEO_BAT.Color(red_mot, green_mot, blue_mot));
  NEO_BAT.show();
}
