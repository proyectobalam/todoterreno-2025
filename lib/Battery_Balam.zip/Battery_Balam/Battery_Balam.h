#ifndef BATTERY_BALAM_H
#define BATTERY_BALAM_H

#include <Arduino.h>
#include <Wire.h>
#include <BQ25887.h>

#include <Adafruit_NeoPixel.h>

struct Colors_Motor {
    int red_mot = 0;
    int green_mot = 0;
    int blue_mot = 0;
};

struct Colors_ESP {
    int red_esp = 0;
    int green_esp = 0;
    int blue_esp = 0;
};

//This function returns the color in RGB of the Motors battery level.
Colors_Motor GET_COLOR_MOTORS_BATTERY(int PIN_ADC_BAT_MOT);

//This function returns the color in RGB of the ESP battery level.
Colors_ESP GET_COLOR_ESP_BATTERY(int PIN_ADC_BAT_ESP);

//This function sets the color to the MOTOR battery level NeoPixel.
void MOTORS_BATTERY_ADC(Adafruit_NeoPixel& NEO_BAT, int PIN_ADC_BAT_MOT);

//This function sets the color to the ESP battery level NeoPixel.
void ESP_BATTERY(Adafruit_NeoPixel& NEO_BAT, int PIN_ADC_BAT_ESP);

//This function sets the color to the ESP battery level NeoPixel.
void MOTORS_BATTERY_I2C(Adafruit_NeoPixel& NEO_BAT, BQ25887& charger, bool status);

//This function returns the ESP battery level (0-100).
int ESP_BATTERY_value(int PIN_ADC_BAT_ESP);

//This function returns the MOTOR battery level (0-100).
int MOTORS_BATTERY_value(int PIN_ADC_BAT_MOT);
	
bool Working(Adafruit_NeoPixel& NEO_BAT);

bool NOT_Working(Adafruit_NeoPixel& NEO_BAT);

#endif